$(document).ready(function(){
	
 /********** Some Variable Initial Value **************/

	var value = $( "#product_filter" ).val();
	var sort = $( "#product_sort" ).val();
	var page=1;
	var txt1="";
	var rs_max1="";
	var rs_min1="";
	var price1 = "";

		
	/**********  Product Filter Start    **************/
	$('#product_filter').on('change', function() {
	  var val = $(this).val();
	  load_data(page,val,sort,txt1,rs_max1,rs_min1,price1);
	  value = val;
     });
	/**********  Product Filter End    **************/

     
     
     /**********  Product Sorting Start    **************/
	 $('#product_sort').on('change', function() {
	  var srt = $(this).val();
	  load_data(page,value,srt,txt1,rs_max1,rs_min1,price1);
	  sort = srt;
     });
     /**********  Product Sorting End    **************/

 
   /*****  Retrieve Value When Page First Load  *******/
    load_data(page,value,sort);


  

     /****  AJAX Main Function Who Perform All Tasks Start *******/
function load_data(page,value,sort,txt,rs_max,rs_min,price){
  	 $.ajax({
	       url: "main_functions.php?page="+page+"&value="+value+"&sort="+sort,
	       method:"GET",
	       data:{
			       	page:page,
			       	srch:txt,
			       	ref_s_max:rs_max,
			       	ref_s_min:rs_min,
			       	range_price:price
	       },
		   beforeSend: function(){
		   $('#image').show();
		   },
		   complete: function(){
		   $('#image').hide();
           },
	       success: function(data){
	       	 $('#products').html(data);
	       }
	})
}
  /****  AJAX Main Function Who Perform All Tasks End *******/


 
 /*****  Pagination Link Function Start  *******/
 $(document).on('click','.paginate',function(){	
    var page = $(this).attr("id");
    load_data(page,value,sort,txt1,rs_max1,rs_min1,price1);
 });
  /*****  Pagination Link Function End  *******/
 

});