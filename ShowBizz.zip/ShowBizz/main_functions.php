<?php 
include('lib/Database.php');
$db = new Database();

  
  /******  Some Default Values Start   ******/
$page = 2;
$search_txt= "";
$output = "";
$rsMax = "";
$rsMin = "";
$rpr = "";
/******  Some Default Values End   ******/

  /******  Check Main Search Bar Have Any Text- Start******/
if(isset($_GET['srch'])){
  $search_txt = $_GET['srch'];
}
  /******  Check Main Search Bar Have Any Text- End******/

 /***  Get Pagination Page,Filter Value And Sort Value - Start ****/
if(isset($_GET['page'])){
  $page = $_GET['page'];
  $value = $_GET['value'];
  $sort = $_GET['sort'];
}else{
	$page = 1;
}
  /***  Get Pagination Page,Filter Value And Sort Value - Start ****/

//echo "<h1>".$rsMax." ".$rsMin."</h1>";
//echo "<h1>".$rpr."</h1>";

   /** Set Filter Value To Product Per Page & Customize Paginate ***/
$record_per_page = 6;
$start_from = ($page-1)* $record_per_page;
?>


 <!--Product Grid Start-->
      
  <div class="product-grid">
  <?php 
  if(isset($_GET['page'])){
	  if(!empty($sort) &&  !empty($value)){
		  $query = "SELECT * from movies where language = '$value' and genere = '$sort' limit $start_from,$record_per_page";
		  $page_query = "SELECT * from movies where language = '$value' and genere = '$sort' order by movie_id DESC";
	  }
	  else if(empty($sort) &&  !empty($value)){
		  $query = "SELECT * from movies where language = '$value' limit $start_from,$record_per_page";
		  $page_query = "SELECT * from movies where language = '$value' order by language DESC";
	  }
	  else if(!empty($sort) &&  empty($value)){
		  $query = "SELECT * from movies where genere = '$sort' limit $start_from,$record_per_page";
		  $page_query = "SELECT * from movies where genere = '$sort' order by language DESC";
	  }
	  else if(empty($sort) &&  empty($value)){
		  $query = "SELECT * from movies where 1 limit $start_from,$record_per_page";
		  $page_query = "SELECT * from movies where 1 order by language DESC";
	  }
  }
  else
  {  
	$query = "SELECT * from movies where 1 limit $start_from,$record_per_page"; 
  }
$result = $db->select($query);
if($result){
	while ($value = $result->fetch_assoc()) { 
	if($value['language'] == 1)
	{
		$new_lan = "Hindi";
	}
	else if($value['language'] == 2)
	{
		$new_lan = "English";
	}
	else if($value['language'] == 3)
	{
		$new_lan = "Tamil";
	}
	if($value['genere'] == 1)
	{
		$new_gen = "Action";
	}
	else if($value['genere'] == 2)
	{
		$new_gen = "Thriller";
	}
	else if($value['genere'] == 3)
	{
		$new_gen = "Comedy";
	}
?>
<div class="col-md-3">
   			  <div class="grid1">
   				<div class="view view-first">
                  <div class="index_img"> <video width="400" controls>
  <source src="videos/<?php echo $value['trailer']; ?>" type="video/mp4"class="img-responsive">
  
  Your browser does not support HTML5 video.
</video></div>
   				    <div class="sale"><?php echo $value['title']; ?></div>
                   </div> 
                   
   				 <div class="inner_wrap">
   				 	<h3><?php echo $value['synopsis']; ?></h3>
   				 	<ul class="star1">
   				 	  <h4 class="green">Langauge: <?php echo $new_lan; ?></h4>
					  <h4 class="green">Genre: <?php echo $new_gen; ?></h4>
   				 	  <li><a href="#">Read More</li>
   				 	</ul>
   				 </div>
   			   </div>
</div>
    <?php } } else{
         
         echo "<h1 style='margin-top:25px;padding:6px;'>OOps!!!! No movies Found</h1>";
      }?>
</div>
        <!--Product Grid End-->
<style>
#image{
	display:none;
}
</style>
 <!--Pagination Part Start-->
<div id="image"><img src="images/loading.gif"></img></div>
        <div class="pagination">
 <?php
  $p_result = $db->select($page_query);
  if($p_result){
     $total_records = mysqli_num_rows($p_result);
   }else
   $total_records=0;
 
  $total_pages = ceil($total_records/$record_per_page);
  for($i=1;$i<= $total_pages;$i++){
  	 ?>
  	
  	   <div class="links">
          <span class="paginate" id="<?php echo $i;?>"><a href="#" style="none"> <b><?php echo $i;?></b> </a></span>
        </div>
          
 <?php } ?>

   </div>
 <!--Pagination Part End-->



